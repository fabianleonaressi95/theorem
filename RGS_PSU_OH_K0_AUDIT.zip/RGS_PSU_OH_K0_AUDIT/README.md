# RGS–PSU: audit di equivarianza di K0 sotto Oh

Questo audit costruisce in modo indipendente la rappresentazione geometrica naturale di Oh dai vertici X_Oh_reconstructed (64x3) e dalla base tangente Q_tangent (192x188) archiviati. I 48 elementi sono le matrici di permutazione con segni degli assi cartesiani che preservano X. L'azione ambientale sui vettori di spostamento viene ristretta al tangente come rho(g)=Q^T P(g) Q.

## Esito
K0 non commuta con la rappresentazione Oh costruita dai dati: solo l'identità fra i 48 elementi ha residuo ||[K0,rho(g)]||_F < 1e-8. Per gli elementi non identità, il residuo mediano è circa 83.12, rispetto a ||K0||_F circa 84.10. Anche PG/P0 non sono invarianti sotto questa rappresentazione (commutatore mediano circa 9.2).

La base Q e la rappresentazione sono validate numericamente: leakage massimo fuori dallo spazio tangente <9.1e-15, errore massimo di ortogonalità rho <4.2e-14.

## Perché non basta un cambio di base
Se si trasformano coerentemente sia K0 sia rho con la stessa matrice ortogonale, il commutatore cambia per coniugazione e la sua norma resta invariata. Un cambio di base non può eliminare il difetto. Bisogna correggere K0, la definizione della simmetria, o la corrispondenza tra le coordinate.

## Perché non basta mediare
La media di gruppo Kbar=(1/48) sum rho(g)^T K0 rho(g) è equivarante per costruzione, ma qui non conserva né il kernel di dimensione 64 né lo spettro a scala 0.5,0.6,...,12.8. È quindi un controllo diagnostico, non una soluzione compatibile con tutte le proprietà originarie.

## Distinzione epistemica
È verificato che K0 è simmetrica e ha 64 autovalori numericamente quasi nulli e 124 autovalori dinamici a ladder. Non è verificata la sua origine come D_omega^dagger D_omega + E_omega, perché i dati originali di connessione e correzione non sono nell'archivio. La dichiarazione di esatta equivarianza Oh è falsificata per la rappresentazione naturale qui ricostruita.
