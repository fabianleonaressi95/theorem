#!/usr/bin/env python3
"""Audit of the recovered 188D K0/P_G/J arrays and Anti-Twin alignment status.

This script deliberately does NOT invent an orthogonal map between the geometric
188D tangent basis Q_tangent(X_Oh) and the abstract 188D K0 basis. Such a map
must be supplied by a shared construction, basis vectors, or a verified set of
intertwining constraints. It tests the exact symmetries that ARE encoded in the
recovered K0/P_G arrays and reports what is and is not established.
"""
from pathlib import Path
import json
import numpy as np
from scipy.linalg import eigh

ROOT = Path(__file__).resolve().parent
# By default, use the recovered files beside this script or under rgs_recovery.
def locate(name):
    candidates = [ROOT / name, ROOT / 'rgs_recovery' / name]
    for p in candidates:
        if p.exists(): return p
    raise FileNotFoundError(f'{name} not found; place it beside script or in rgs_recovery/')

K = np.asarray(np.load(locate('K0.npy')), float)
P = np.asarray(np.load(locate('P_G.npy')), float)
JA = np.asarray(np.load(locate('J_A.npy')), float)
JB = np.asarray(np.load(locate('J_B.npy')), float)
J = np.asarray(np.load(locate('J.npy')), float)

n = K.shape[0]
I = np.eye(n)
assert K.shape == P.shape == (188,188)
assert JA.shape == JB.shape == (188,3)
assert J.shape == (188,6)

# This is a gauge-sector involution induced by P_G, NOT claimed to be Anti-Twin.
Sg = 2*P - I
wK = eigh(K, eigvals_only=True)
tolK = 1e-10 * max(1.0, abs(wK[0]), abs(wK[-1]))

report = {
  'scope': 'Recovered abstract 188D kernel arrays; no verified basis map to geometric Q_tangent(X_Oh).',
  'shapes': {'K0': list(K.shape), 'P_G': list(P.shape), 'J_A': list(JA.shape), 'J_B': list(JB.shape), 'J': list(J.shape)},
  'K0': {
    'symmetry_residual_fro': float(np.linalg.norm(K-K.T, 'fro')),
    'eigenvalue_min': float(wK[0]), 'eigenvalue_max': float(wK[-1]),
    'eigenvalue_counts_tol': {'negative': int(np.sum(wK < -tolK)), 'zero': int(np.sum(np.abs(wK)<=tolK)), 'positive': int(np.sum(wK>tolK))},
  },
  'P_G': {
    'symmetry_residual_fro': float(np.linalg.norm(P-P.T,'fro')),
    'idempotence_residual_fro': float(np.linalg.norm(P@P-P,'fro')),
    'rank_numeric': int(np.linalg.matrix_rank(P, tol=1e-8)),
    'commutator_K0_residual_fro': float(np.linalg.norm(P@K-K@P,'fro')),
  },
  'induced_gauge_involution_Sg_2PG_minus_I': {
    'warning': 'Control symmetry only; NOT identified with Anti-Twin.',
    'orthogonality_residual_fro': float(np.linalg.norm(Sg.T@Sg-I,'fro')),
    'involution_residual_fro': float(np.linalg.norm(Sg@Sg-I,'fro')),
    'commutator_K0_residual_fro': float(np.linalg.norm(Sg@K-K@Sg,'fro')),
    'eigenvalue_counts': {'minus_one': int(np.sum(np.isclose(eigh(Sg,eigvals_only=True),-1,atol=1e-8))), 'plus_one': int(np.sum(np.isclose(eigh(Sg,eigvals_only=True),1,atol=1e-8)))},
  },
  'channel_projection_under_PG': {},
  'anti_twin_alignment': {
    'status': 'NOT TESTABLE FROM RECOVERED ARRAYS ALONE',
    'reason': 'No shared coordinate map or paired geometric tangent basis is present. An arbitrary orthogonal alignment would make the commutator test meaningless.',
    'required_input': 'Original X_Oh_reconstructed.npy plus a documented construction linking its 188D tangent coordinates to the stored K0 basis, or the original shared 188D basis/intertwiner.'
  }
}
for name, A in [('J_A',JA),('J_B',JB),('J',J)]:
    Ap=P@A; Am=(I-P)@A
    report['channel_projection_under_PG'][name] = {
      'fro_norm': float(np.linalg.norm(A,'fro')),
      'PG_component_norm': float(np.linalg.norm(Ap,'fro')),
      'PF_component_norm': float(np.linalg.norm(Am,'fro')),
      'PG_fraction_squared': float(np.linalg.norm(Ap,'fro')**2 / max(np.linalg.norm(A,'fro')**2,1e-300)),
      'PF_fraction_squared': float(np.linalg.norm(Am,'fro')**2 / max(np.linalg.norm(A,'fro')**2,1e-300)),
    }

out = ROOT / 'RGS_PSU_alignment_K0_audit.json'
out.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
print('\nWROTE', out)
